<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    @php
        $template = App\Models\Template::where('id', '<>', '~')->first();
    @endphp
    <title>{{ $template->nama }}</title>
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/3.1.2/es5/tex-mml-chtml.min.js"
        integrity="sha384-KyZXEAg3QhqLMpG8r+v\/ZzXt86G2nM+T\/yKLtE3mvMoi0A2VkuH5FoMIpZoCUWxrc" crossorigin="anonymous">
        </script>
    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- plugins:css -->
    <link rel="stylesheet" href="{{ asset('layout/skydash/vendors/feather/feather.css') }}">
    <link rel="stylesheet" href="{{ asset('layout/skydash/vendors/ti-icons/css/themify-icons.css') }}">
    <link rel="stylesheet" href="{{ asset('layout/skydash/vendors/css/vendor.bundle.base.css') }}">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="{{ asset('layout/skydash/vendors/datatables.net-bs4/dataTables.bootstrap4.css') }}">
    <link rel="stylesheet" href="{{ asset('layout/skydash/vendors/ti-icons/css/themify-icons.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('layout/skydash/js/select.dataTables.min.css') }}">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="{{ asset('layout/skydash/css/vertical-layout-light/style.css') }}">
    <!-- endinject -->
    <link rel="shortcut icon" href="{{ asset($template->logo_kecil) }}" />
    <link rel="stylesheet" href="{{ asset('layout/skydash/vendors/mdi/css/materialdesignicons.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/skydash.css') }}?v=<?php echo rand(); ?>">
    <script src="https://kit.fontawesome.com/f121295e13.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    @section('header')
    @show
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center d-sm-none"
                style="background:#171A26;">
                <a class="navbar-brand brand-logo mr-5" href="https://apps.belajarsoal.id/"><img
                        src="{{ asset($template->logo_besar) }}" class="mr-2" alt="logo" /></a>
                <a class="navbar-brand brand-logo-mini" href="https://apps.belajarsoal.id/"><img
                        src="{{ asset($template->logo_kecil) }}" alt="logo" /></a>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end" style="background:#171A26;">
                <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                    <span class="icon-menu"></span>
                </button>

                @php
                    $cekdata = App\Models\Transaksi::where('fk_user_id', '=', Auth::user()->id)
                        ->where('status', 0)
                        ->get();
                    $cekdatakeranjang = App\Models\Keranjang::where('fk_user_id', '=', Auth::user()->id)
                        ->where('status', 0)
                        ->get();
                @endphp
                <ul class="navbar-nav navbar-nav-right">

                    <li class="nav-item dropdown">
                        <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#"
                            data-toggle="dropdown">
                            <i class="icon-bell mx-0" style="color: white;"></i>
                            @if (count($cekdata) > 0)
                                <span class="count"></span>
                            @endif
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list"
                            aria-labelledby="notificationDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">Notifikasi</p>
                            <a href="{{ url('pembelian') }}" class="dropdown-item preview-item">
                                <div class="preview-thumbnail">
                                    <div class="preview-icon bg-warning">
                                        <i class="ti-shopping-cart mx-0"></i>
                                    </div>
                                </div>
                                <div class="preview-item-content">
                                    <h6 class="preview-subject font-weight-normal text-white">Transaksi</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        @if (count($cekdata) > 0)
                                            {{ count($cekdata) }} transaksi belum dibayar
                                        @else
                                            Belum ada transaksi baru
                                        @endif
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
                            <img src="{{ Auth::user()->photo ? asset(Auth::user()->photo) : asset('image/global/unknown_user.png') }}"
                                alt="profile" />
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="profileDropdown">
                            <a class="dropdown-item" href="{{ route('logout') }}"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                <i class="ti-power-off text-primary"></i>
                                <strong style="color: black;">Logout</strong>
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </li>

                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="icon-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <div class="theme-setting-wrapper">
                <div id="settings-trigger" data-bs-toggle="tooltip" data-bs-placement="top"
                    title="Klik Untuk Informasi Lebih Lanjut">
                    <a href="https://api.whatsapp.com/send/?phone=6285766908058&text=Halo+Belajar+Soal%21+Saya+Ingin+Bertanya+Tentang...&type=phone_number&app_absent=0"
                        style="border-radius: 50%;" target="_blank" type="button"
                        class="btn btn-success btn-sm btn-icon-text wa-button" style="white-space:nowrap">
                        <img width="30px" src="{{ asset('image/global/wa.png') }}" alt="">
                    </a>
                </div>
            </div>
            <div id="right-sidebar" class="settings-panel">
                <i class="settings-close ti-close"></i>
                <ul class="nav nav-tabs border-top" id="setting-panel" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="todo-tab" data-toggle="tab" href="#todo-section" role="tab"
                            aria-controls="todo-section" aria-expanded="true">TO DO LIST</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="chats-tab" data-toggle="tab" href="#chats-section" role="tab"
                            aria-controls="chats-section">CHATS</a>
                    </li>
                </ul>
                <div class="tab-content" id="setting-content">
                    <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel"
                        aria-labelledby="todo-section">
                        <div class="add-items d-flex px-3 mb-0">
                            <form class="form w-100">
                                <div class="form-group d-flex">
                                    <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                                    <button type="submit" class="add btn btn-primary todo-list-add-btn"
                                        id="add-task">Add</button>
                                </div>
                            </form>
                        </div>
                        <div class="list-wrapper px-3">
                            <ul class="d-flex flex-column-reverse todo-list">
                                <li>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="checkbox" type="checkbox">
                                            Team review meeting at 3.00 PM
                                        </label>
                                    </div>
                                    <i class="remove ti-close"></i>
                                </li>
                                <li>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="checkbox" type="checkbox">
                                            Prepare for presentation
                                        </label>
                                    </div>
                                    <i class="remove ti-close"></i>
                                </li>
                                <li>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="checkbox" type="checkbox">
                                            Resolve all the low priority tickets due today
                                        </label>
                                    </div>
                                    <i class="remove ti-close"></i>
                                </li>
                                <li class="completed">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="checkbox" type="checkbox" checked>
                                            Schedule meeting for next week
                                        </label>
                                    </div>
                                    <i class="remove ti-close"></i>
                                </li>
                                <li class="completed">
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input class="checkbox" type="checkbox" checked>
                                            Project review
                                        </label>
                                    </div>
                                    <i class="remove ti-close"></i>
                                </li>
                            </ul>
                        </div>
                        <h4 class="px-3 text-muted mt-5 font-weight-light mb-0">Events</h4>
                        <div class="events pt-4 px-3">
                            <div class="wrapper d-flex mb-2">
                                <i class="ti-control-record text-primary mr-2"></i>
                                <span>Feb 11 2018</span>
                            </div>
                            <p class="mb-0 font-weight-thin text-gray">Creating component page build a js</p>
                            <p class="text-gray mb-0">The total number of sessions</p>
                        </div>
                        <div class="events pt-4 px-3">
                            <div class="wrapper d-flex mb-2">
                                <i class="ti-control-record text-primary mr-2"></i>
                                <span>Feb 7 2018</span>
                            </div>
                            <p class="mb-0 font-weight-thin text-gray">Meeting with Alisa</p>
                            <p class="text-gray mb-0 ">Call Sarah Graves</p>
                        </div>
                    </div>
                    <!-- To do section tab ends -->
                    <div class="tab-pane fade" id="chats-section" role="tabpanel" aria-labelledby="chats-section">
                        <div class="d-flex align-items-center justify-content-between border-bottom">
                            <p class="settings-heading border-top-0 mb-3 pl-3 pt-0 border-bottom-0 pb-0">Friends</p>
                            <small
                                class="settings-heading border-top-0 mb-3 pt-0 border-bottom-0 pb-0 pr-3 font-weight-normal">See
                                All</small>
                        </div>
                        <ul class="chat-list">
                            <li class="list active">
                                <div class="profile"><img src="{{ asset('layout/skydash/images/faces/face1.jpg') }}"
                                        alt="image"><span class="online"></span></div>
                                <div class="info">
                                    <p>Thomas Douglas</p>
                                    <p>Available</p>
                                </div>
                                <small class="text-muted my-auto">19 min</small>
                            </li>
                            <li class="list">
                                <div class="profile"><img src="{{ asset('layout/skydash/images/faces/face2.jpg') }}"
                                        alt="image"><span class="offline"></span></div>
                                <div class="info">
                                    <div class="wrapper d-flex">
                                        <p>Catherine</p>
                                    </div>
                                    <p>Away</p>
                                </div>
                                <div class="badge badge-success badge-pill my-auto mx-2">4</div>
                                <small class="text-muted my-auto">23 min</small>
                            </li>
                            <li class="list">
                                <div class="profile"><img src="{{ asset('layout/skydash/images/faces/face3.jpg') }}"
                                        alt="image"><span class="online"></span></div>
                                <div class="info">
                                    <p>Daniel Russell</p>
                                    <p>Available</p>
                                </div>
                                <small class="text-muted my-auto">14 min</small>
                            </li>
                            <li class="list">
                                <div class="profile"><img src="{{ asset('layout/skydash/images/faces/face4.jpg') }}"
                                        alt="image"><span class="offline"></span></div>
                                <div class="info">
                                    <p>James Richardson</p>
                                    <p>Away</p>
                                </div>
                                <small class="text-muted my-auto">2 min</small>
                            </li>
                            <li class="list">
                                <div class="profile"><img src="{{ asset('layout/skydash/images/faces/face5.jpg') }}"
                                        alt="image"><span class="online"></span></div>
                                <div class="info">
                                    <p>Madeline Kennedy</p>
                                    <p>Available</p>
                                </div>
                                <small class="text-muted my-auto">5 min</small>
                            </li>
                            <li class="list">
                                <div class="profile"><img src="{{ asset('layout/skydash/images/faces/face6.jpg') }}"
                                        alt="image"><span class="online"></span></div>
                                <div class="info">
                                    <p>Sarah Graves</p>
                                    <p>Available</p>
                                </div>
                                <small class="text-muted my-auto">47 min</small>
                            </li>
                        </ul>
                    </div>
                    <!-- chat tab ends -->
                </div>
            </div>
            <!-- partial -->
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar" style="background:#171A26;">
                <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                    <a class="navbar-brand brand-logo m-0" href="https://apps.belajarsoal.id/"><img
                            src="{{ asset($template->logo_besar) }}" alt="logo" /></a>
                    <a class="navbar-brand brand-logo-mini m-0" href="https://apps.belajarsoal.id/"><img
                            src="{{ asset($template->logo_kecil) }}?v=1" alt="logo" /></a>
                </div>
                <ul class="nav">
                    <li class="single-sidebar-menu">
                        <div class="menulabel text-white">menu</div><!---->
                    </li>
                    <li class="nav-item {{ $menu == 'home' ? 'active' : '' }}">
                        <a class="nav-link _nav-link" href="#" _ceklink=""
                            _link="{{ Auth::user()->user_level == 3 ? url('dashboard') : url('home') }}">
                            <i class="ti-home menu-icon"></i>
                            <span class="menu-title">Home</span>
                        </a>
                    </li>
                    <li class="nav-item {{ $menu == 'belipaket' ? 'active' : '' }}">
                        <a class="nav-link _nav-link" href="#" _ceklink="" _link="{{ url('belipaket') }}">
                            <i class="ti-bag menu-icon"></i>
                            <span class="menu-title">Beli Paket</span>
                        </a>
                    </li>
                    <li class="nav-item {{ $menu == 'pembelian' ? 'active' : '' }}">
                        <a class="nav-link _nav-link" href="#" _ceklink="" _link="{{ url('pembelian') }}">
                            <i class="ti-bag menu-icon"></i>
                            <span class="menu-title">Pembelian</span>
                        </a>
                    </li>

                    <li class="nav-item {{ $menu == 'paketsayaktg' ? 'active' : 'nonactive' }}">
                        <a class="nav-link collapsed" data-bs-toggle="collapse" href="#paketsayaktg"
                            aria-expanded="false" aria-controls="paketsayaktg">
                            <i class="ti-folder menu-icon"></i>
                            <span class="menu-title">Paket Saya</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="paketsayaktg" style="color:white;">
                            <ul class="nav flex-column sub-menu" style="color:white;">
                                @php
                                    $cekdata = App\Models\Transaksi::where('fk_user_id', Auth::user()->id)
                                        ->where('status', 1)
                                        ->pluck('fk_paket_mst');
                                    $kategori = App\Models\PaketMst::whereIn('id', $cekdata)
                                        ->orderBy('judul', 'asc')
                                        ->get();
                                    foreach ($kategori as $data) {
                                        echo '<li class="nav-item" style="color:white !important;"><a class="nav-link text-white" style="color:white !important;" href="' .
                                            url('paketsayadetail') .
                                            '/' .
                                            Crypt::encrypt($data->id) .
                                            '">' .
                                            $data->judul .
                                            '</a></li>';
                                    }
                                @endphp
                                <li class="nav-item"><a class="nav-link" href="{{ url('paketgratis') }}">Paket
                                        Gratis</a></li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item {{ $menu == 'tryout' ? 'active' : '' }}">
                        <!-- <a class="nav-link _nav-link" href="#" _ceklink="tryout" _link="{{ url('tryout') }}"> -->
                        <a class="nav-link _nav-link" href="#" _ceklink="tryout" _link="{{ url('tryout') }}">
                            <i class="ti-desktop menu-icon"></i>
                            <span class="menu-title">Try Out Akbar</span>
                        </a>
                    </li>
                    <li class="nav-item {{ $menu == 'informasi-user' ? 'active' : '' }}">
                        <!-- <a class="nav-link _nav-link" href="#" _ceklink="informasi-user" _link="{{ url('informasi-user') }}"> -->
                        <a class="nav-link _nav-link" href="{{ url('informasi-user') }}" _ceklink="informasi-user"
                            _link="{{ url('informasi-user') }}">
                            <i class="ti-help menu-icon"></i>
                            <span class="menu-title">Informasi</span>
                        </a>
                    </li>
                    <li class="nav-item {{ $menu == 'faq' ? 'active' : '' }}">
                        <a class="nav-link _nav-link" href="{{ url('faq') }}" _ceklink="faq" _link="{{ url('faq') }}">
                            <i class="ti-help menu-icon"></i>
                            <span class="menu-title">FAQ</span>
                        </a>
                    </li>
                    <li class="single-sidebar-menu mt-3">
                        <div class="menulabel text-white">pengaturan</div><!---->
                    </li>
                    <li class="nav-item {{ $menu == 'profiluser' ? 'active' : '' }}">
                        <a class="nav-link _nav-link" href="#" _ceklink="profiluser" _link="{{ url('profileuser') }}">
                            <i class="ti-user menu-icon"></i>
                            <span class="menu-title">Akun Saya</span>
                        </a>
                    </li>
                    <li class="nav-item mt-4">
                        <a class="nav-link _nav-link btn btn-primary bg-blue rounded-pill text-white border-0 text-center d-block justify-content-center"
                            href="#" _ceklink="logout" _link="{{ url('logout') }}">
                            <i class="ti-power-off  menu-icon me-1 text-white"></i>
                            <span class="menu-title" style="color: white;">Logout</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item {{ $menu == 'hasilujian' ? 'active' : '' }}">
            <a class="nav-link _nav-link" href="#" _ceklink="" _link="{{ url('hasilujian') }}">
              <i class="icon-layout menu-icon"></i>
              <span class="menu-title">Hasil Ujian</span>
            </a>
          </li> -->
                </ul>
            </nav>
            <div class="main-panel">
                @section('content')
                @show
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <footer class="footer" style="background:#171A26;">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span
                            class="text-white text-center text-sm-left d-block d-sm-inline-block">{{ $template->copyright }}</span>
                        <!-- <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="ti-heart text-danger ml-1"></i></span> -->
                    </div>
                    <!-- <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Distributed by <a href="https://www.themewagon.com/" target="_blank">Themewagon</a></span>
          </div> -->
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- plugins:js -->
    <script src="{{ asset('layout/skydash/vendors/js/vendor.bundle.base.js') }}"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="{{ asset('layout/skydash/vendors/chart.js/Chart.min.js') }}"></script>
    <script src="{{ asset('layout/skydash/vendors/datatables.net/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('layout/skydash/vendors/datatables.net-bs4/dataTables.bootstrap4.js') }}"></script>
    <script src="{{ asset('layout/skydash/js/dataTables.select.min.js') }}"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="{{ asset('layout/skydash/js/off-canvas.js') }}"></script>
    <script src="{{ asset('layout/skydash/js/hoverable-collapse.js') }}"></script>
    <script src="{{ asset('layout/skydash/js/template.js') }}"></script>
    <script src="{{ asset('layout/skydash/js/settings.js') }}"></script>
    <script src="{{ asset('layout/skydash/js/todolist.js') }}"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="{{ asset('layout/skydash/js/dashboard.js') }}"></script>
    <script src="{{ asset('layout/skydash/js/Chart.roundedBarCharts.js') }}"></script>
    <script src="{{ asset('js/global.js') }}"></script>
    <script src="{{ asset('layout/adminlte3/plugins/jquery/jquery.min.js') }}"></script>
    <script src='https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js'>
    </script>
    <!-- jQuery -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function () {
            $("._nav-link").on('click', function () {
                link = $(this).attr('_link');
                ceklink = $(this).attr('_ceklink');
                if (ceklink == "paketsayaktg") {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        dataType: "JSON",
                        url: "{{ url('cekujian') }}",
                        data: "id=0",
                        // contentType: false,
                        // processData: false,
                        beforeSend: function () {
                            $.LoadingOverlay("show", {
                                image: "{{ asset('/image/global/loading.gif') }}"
                            });
                        },
                        success: function (response) {
                            if (response.status === true) {
                                window.location.href = '{{ url('paketsayaktg') }}';
                                return false;
                            } else {
                                Swal.fire({
                                    icon: 'warning',
                                    html: response.message,
                                    showDenyButton: true,
                                    showCancelButton: true,
                                    confirmButtonText: 'Lanjutkan',
                                    cancelButtonText: 'Batal',
                                    denyButtonText: 'Selesaikan Ujian',
                                }).then((result) => {
                                    /* Read more about isConfirmed, isDenied below */
                                    if (result.isConfirmed) {
                                        window.location.href = '{{ url('ujian') }}/' +
                                            response.idpaket;
                                    } else if (result.isDenied) {
                                        // Selesaikan Ujian
                                        idpaketmst = response.idpaket;
                                        $.ajaxSetup({
                                            headers: {
                                                'X-CSRF-TOKEN': $(
                                                    'meta[name="csrf-token"]'
                                                )
                                                    .attr('content')
                                            }
                                        });
                                        $.ajax({
                                            type: "POST",
                                            dataType: "JSON",
                                            url: "{{ url('selesaiujian') }}",
                                            // async: false,
                                            data: {
                                                idpaketmst: idpaketmst
                                            },
                                            beforeSend: function () {
                                                $.LoadingOverlay("show", {
                                                    image: "{{ asset('/image/global/loading.gif') }}"
                                                });
                                            },
                                            success: function (response) {
                                                if (response.status) {
                                                    $('.modal').modal(
                                                        'hide');
                                                    Swal.fire({
                                                        html: response
                                                            .message,
                                                        icon: 'success',
                                                        showConfirmButton: true
                                                    }).then((
                                                        result) => {
                                                        $.LoadingOverlay(
                                                            "show", {
                                                            image: "{{ asset('/image/global/loading.gif') }}"
                                                        });
                                                        reload_url(
                                                            1500,
                                                            '{{ url('paketsayaktg') }}'
                                                        );
                                                    })
                                                } else {
                                                    Swal.fire({
                                                        html: response
                                                            .message,
                                                        icon: 'error',
                                                        confirmButtonText: 'Ok'
                                                    });
                                                }
                                            },
                                            error: function (xhr, status) {
                                                alert('Error!!!');
                                            },
                                            complete: function () {
                                                $.LoadingOverlay("hide");
                                            }
                                        });
                                        // Akhir Selesaikan Ujian
                                    }
                                });
                            }
                        },
                        error: function (xhr, status) {
                            alert('Error!!!');
                        },
                        complete: function () {
                            $.LoadingOverlay("hide");
                        }
                    });
                } else {
                    window.location.href = link;
                    return false;
                }
            });
        });
    </script>
    <!-- End custom js for this page-->
    @section('footer')
    @show
</body>

</html>