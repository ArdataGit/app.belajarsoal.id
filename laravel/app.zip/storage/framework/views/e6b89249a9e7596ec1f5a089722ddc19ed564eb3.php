<?php $__env->startSection('content'); ?>
    <?php
        $gratis = $gratis ? '/gratis' : '';
    ?>

    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="cardx card-border w-100">
                    <div class="card-bodyx w-100">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item text-white"><a href="<?php echo e(url('home')); ?>"><i
                                            class="fas fa-home"></i></a></li>
                                <li class="breadcrumb-item active text-white" aria-current="page"><a
                                        href="<?php echo e(url('paketsayaktg')); ?>">Paket Saya</a></li>
                                <li class="breadcrumb-item active text-white" aria-current="page"><?php echo e($kategori->judul); ?>

                                </li>
                            </ol>
                        </nav>
                        <p class="card-description">
                        <h3 class="font-weight-bold text-white"><b>Pilih <?php echo e($kategori->judul); ?></b></h3>
                        </p>
                        <div class="row mt-4">
                            <?php $__empty_1 = true; $__currentLoopData = $subkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4 mb-4 stretch-card">
                                    <div class="card">
                                        <div class="card-body py-4">
                                            <div class="row align-items-center mb-3" style="flex-wrap: nowrap !important;">
                                                <div class="col-2">

                                                    <div class="icon-card bg-blue rounded-circle iconpaket">
                                                        <i class="p-2 ti-layers-alt"></i>
                                                    </div>

                                                </div>
                                                <div class="col-8">
                                                    <h4 class="fs-6 mb-0 text-white ml-3"><b><?php echo e($key->judul); ?></b></h4>
                                                    <div class="text-sm mt-2 ml-3 text-white"><?php echo $key->ket; ?></div>
                                                </div>
                                            </div>
                                            <a href="<?php echo e(url('paketsaya')); ?>/<?php echo e(Crypt::encrypt($key->id)); ?>"
                                                class="hrefpaket btn btn-primary bg-green text-white rounded-pill d-flex align-items-center justify-content-center">Pilih
                                                Paket <i class="ti-arrow-right ms-2" style="font-size: 10pt;"></i></a>
                                        </div>
                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <center><img class="mb-3 img-no" src="<?php echo e(asset('image/global/no-paket.png')); ?>" alt=""></center>
                                <br>
                                <center text-white>Belum Ada Data</center>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <!-- SweetAlert2 -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
        $(document).ready(function () {
            $(document).on('click', '.btn-kerjakan', function (e) {

            });
        });
    </script>
    <!-- Loading Overlay -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Skydash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dharmara/apps.belajarsoal.id/laravel/resources/views/user/paketsayasubktg.blade.php ENDPATH**/ ?>