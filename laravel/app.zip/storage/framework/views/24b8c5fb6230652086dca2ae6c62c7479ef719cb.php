<style>
    .tombol {
        background: #028618;
        padding: 5px 15px;
        text-decoration: none;
        color: white;
        border-radius: 4px;
    }

    .footer {
        text-align: center;
        padding: 25px;
        background: lightgray;
    }
</style>
<h3>Hi, <?php echo e($nama); ?> !</h3>

<p>Email anda adalah <?php echo e($email); ?></p>
<p>dan Password Anda adalah <?php echo e($password); ?> harap simpan password Anda dengan baik</p>
<p>jika ada pertanyaan, silahkan hubungi no wa: <?php echo e($notlp); ?></p>
<p>Terima Kasih</p>
<p><?php echo e($namaweb); ?></p>

<div class="footer">
    <p>Email ini adalah layanan yang disediakan oleh <?php echo e($namaweb); ?></p>
    <p>©<?php echo e(date("Y")); ?> <?php echo e($namaweb); ?> - <?php echo e($_SERVER['SERVER_NAME']); ?></p>
</div><?php /**PATH /home/dharmara/apps.belajarsoal.id/laravel/resources/views/email/register.blade.php ENDPATH**/ ?>