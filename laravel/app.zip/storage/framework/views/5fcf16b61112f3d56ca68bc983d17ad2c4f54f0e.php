<!-- partial -->
<?php $__env->startSection('content'); ?>
    <style>
        .form-check .form-check-label input[type="radio"]+.input-helper:before {
            cursor: unset;
        }

        iframe {
            width: 100% !important;
        }

        .btn-tab {
            border: 1px solid transparent !important;
            color: #686868;
        }

        .btn-tab:focus {
            box-shadow: unset !important;
        }

        .badge-danger {
            background-color: rgb(158, 55, 55) !important;
        }

        ._form-check-success {
            color: green;
        }
    </style>
    <?php
        if (app('request')->input('tab')) {
            $tab = app('request')->input('tab');
        } else {
            $tab = 'statistik';
        }
        if ($upaketsoalmst->is_kkm) {
            $lulus = true;
            foreach ($upaketsoalmst->u_paket_soal_ktg_r as $key) {
                if ($key->nilai < $key->kkm) {
                    $lulus = false;
                }
            }
        } else {
            $lulus = $upaketsoalmst->nilai >= $upaketsoalmst->kkm;
        }
        function check_decimal($number)
        {
            $number = number_format($number, 2, ',', ' ');
            if (substr($number, -1) == '0') {
                $number = substr($number, 0, -1);
            }
            if (substr($number, -2) == ',0') {
                $number = substr($number, 0, -2);
            }
            return $number;
        }
    ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card card-border">
                    <div class="card-body">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>"><i class="fas fa-home"></i></a></li>
                                <li class="breadcrumb-item active text-white" aria-current="page">Paket Saya</li>
                                <li class="breadcrumb-item active text-white" aria-current="page">Hasil & Pembahasan</li>
                            </ol>
                        </nav>
                        <p class="card-description">
                        <h3 class="font-weight-bold text-white"><b>Detail Hasil Latihan</b></h3>
                        <div class="row">
                            <div class="col-12 col-md-3 col-lg-3">
                                <table class="table table-borderless text-white">
                                    <thead>
                                        <tr>
                                            <th class="pb-0" style="padding-left:0px">Latihan</th>
                                            <th class="pb-0 text-white"><?php echo e($upaketsoalmst->judul); ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left:0px">Nama</th>
                                            <th><?php echo e(Auth::user()->name); ?></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                            <div class="col-12">
                                <ul class="pb-3 nav nav-pills btn-menu-paket" role="tablist">
                                    <li class="nav-item">
                                        <a style=""
                                            class="btn btn-sm btn-primary nav-link btn-tab-hasil btn-tab <?php echo e($tab == 'statistik' ? 'active' : ''); ?>"
                                            data-toggle="pill" href="#statistik"><i class="fas fa-chart-pie"></i> Hasil</a>
                                    </li>
                                    <li class="nav-item">
                                        <a style="text-white"
                                            class="btn btn-sm btn-primary nav-link btn-tab-hasil btn-tab <?php echo e($tab == 'pembahasan' ? 'active' : ''); ?>"
                                            data-toggle="pill" href="#pembahasan"><i class="fa fa-list-alt"></i>
                                            Pembahasan</a>
                                    </li>
                                </ul>
                                <div class="tab-content tab-hasil-ujian">
                                    <div id="statistik" class="tab-pane <?php echo e($tab == 'statistik' ? 'active' : ''); ?>"><br>
                                        <div class="text-black" style="overflow: hidden">
                                            <h4>Skor hasil perolehan <span
                                                    class="badge badge-info"><?php echo e($upaketsoalmst->judul); ?></span></h4>
                                            <?php if(!$lulus): ?>
                                                <div class="badge badge-danger rounded-3 w-100 py-3 mt-2">
                                                    <h5 class="mb-0 p-0">Maaf Anda Tidak Lulus</h5>
                                                </div>
                                            <?php else: ?>
                                                <div class="badge badge-success rounded-3 w-100 py-3 mt-2">
                                                    <h5 class="mb-0 p-0">Selamat Anda Lulus</h5>
                                                </div>
                                            <?php endif; ?>
                                            <div class="row mt-3" style="justify-content: center">
                                                <div class="col-12 col-md-3"
                                                    style="background: #ccf1d0e3 !important;margin-left:0.5%;margin-right:0.5%;border-radius:10px">
                                                    <div class="px-3 py-5 card-border"
                                                        style="text-align:center;border-radius:10px;display:flex;flex-direction:column;justify-content:center">
                                                        <?php
                                                            $getpoint = App\Models\UPaketSoalDtl::select('max_point')
                                                                ->where('fk_u_paket_soal_mst', $upaketsoalmst->id)
                                                                ->sum('max_point');
                                                        ?>
                                                        <div style="display:flex;justify-content:center">
                                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                                style="height: 50px;width:50px;color:green;background-color:white;border-radius:100%;padding:10px;margin-bottom:10px">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="M10.5 6a7.5 7.5 0 1 0 7.5 7.5h-7.5V6Z" />
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="M13.5 10.5H21A7.5 7.5 0 0 0 13.5 3v7.5Z" />
                                                            </svg>
                                                        </div>
                                                        <h6 class="fw-bold mt-3 text-black">Total Skor</h6>
                                                        <div class="">
                                                            <span
                                                                style="font-size: 36pt;color: #106571;font-weight: bold;display: block;">
                                                                <?php echo e(check_decimal($upaketsoalmst->nilai)); ?>

                                                            </span>
                                                            <?php if(!$upaketsoalmst->is_kkm): ?>
                                                                <h6 class="fw-bold mt-3 text-center text-black">KKM
                                                                    <?php echo e($upaketsoalmst->kkm); ?> </h6>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php $__currentLoopData = $upaketsoalmst->u_paket_soal_ktg_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-12 col-sm-3 mt-3"
                                                        style="background: #EFFFF1 !important;margin-left:0.5%;margin-right:0.5%;border-radius:10px">
                                                        <div class="px-3 py-5 card-border"
                                                            style="text-align:center;border-radius:10px;display:flex;flex-direction:column;justify-content:center">
                                                            <div style="display:flex;justify-content:center">
                                                                <svg style="height: 50px;width:50px;color:blue;background-color:white;border-radius:100%;padding:10px;margin-bottom:10px"
                                                                    xmlns="http://www.w3.org/2000/svg" fill="none"
                                                                    viewBox="0 0 24 24" stroke-width="1.5"
                                                                    stroke="currentColor" class="w-6 h-6">
                                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                                        d="M3.75 3v11.25A2.25 2.25 0 0 0 6 16.5h2.25M3.75 3h-1.5m1.5 0h16.5m0 0h1.5m-1.5 0v11.25A2.25 2.25 0 0 1 18 16.5h-2.25m-7.5 0h7.5m-7.5 0-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0-.5 1.5m.75-9 3-3 2.148 2.148A12.061 12.061 0 0 1 16.5 7.605" />
                                                                </svg>
                                                            </div>
                                                            <h6 class="fw-bold mt-3 text-black"><?php echo e($key->judul); ?></h6>
                                                            <div class=""><span
                                                                    style="font-size: 26pt;color: #106571;font-weight: bold;display: block;">
                                                                    <?php if($key->bobot): ?>
                                                                        <?php echo e(check_decimal((float) ($key->nilai * (float) ($key->bobot / 100.0)))); ?>

                                                                    <?php elseif($key->fk_u_paket_soal_kecermatan_mst): ?>
                                                                        <?php echo e($key->point <= 0 ? 0 : check_decimal($key->point)); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e(check_decimal($key->nilai)); ?>

                                                                    <?php endif; ?>
                                                                </span>
                                                            </div>
                                                            <?php if($upaketsoalmst->is_kkm == 1): ?>
                                                                <h6 class="fw-bold mt-3 text-black">KKM <?php echo e($key->kkm); ?>

                                                                </h6>
                                                                <h6>
                                                                    <?php if($key->nilai >= $key->kkm): ?>
                                                                        <span class="badge badge-info">Lulus</span>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">Tidak Lulus</span>
                                                                    <?php endif; ?>
                                                                </h6>
                                                            <?php elseif($key->bobot): ?>
                                                                <h6 class="fw-bold mt-3 text-black">Nilai Sesi
                                                                    <?php echo e(check_decimal($key->nilai)); ?></h6>
                                                                <!--<h6 class="fw-bold mt-3 text-white">Bobot <?php echo e($key->bobot); ?> %</h6>-->
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="pembahasan" class="tab-pane <?php echo e($tab == 'pembahasan' ? 'active' : ''); ?>"><br>
                                        <div class="row">
                                            <div class="col-xl-9 col-md-9 col-sm-9 col-xs-9 text-white">
                                                <?php if($upaketsoalmst->bagi_jawaban == 0 || $upaketsoalmst->jenis_pembahasan == 1): ?>
                                                    <div class="_soal_content tab-content" id="pills-tabContent">
                                                        <?php $__currentLoopData = $upaketsoalmst->u_paket_soal_ktg_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upaketktg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $upaketktg->u_paket_soal_dtl_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="tab-pane-soal tab-pane fade <?php echo e($key->no_soal == 1 ? 'show active' : ''); ?>"
                                                                    id="pills-<?php echo e($key->id); ?>" role="tabpanel">
                                                                    <h4 class="ktg-soal text-white">
                                                                        <?php echo e($upaketsoalmst->jenis_waktu == 1 ? 'Kategori' : 'Sesi'); ?>

                                                                        <?php echo e($upaketktg->judul); ?></h4>
                                                                    <!-- <h6><b>[<?php echo e($key->nama_tingkat); ?>]</b></h6> -->
                                                                    <div class="mb-3 p-3 card-border"
                                                                        style="border-radius: 10px;">
                                                                        <div class="row">
                                                                            <div class="col-6">
                                                                                <h4 class="mb-0 mt-0 text-white"><b>Soal
                                                                                        No.<?php echo e($key->no_soal); ?></b>
                                                                                    <?php if($upaketsoalmst->bagi_jawaban == 1): ?>
                                                                                        <?php if($key->jawaban_user): ?>
                                                                                            <?php if($key->jawaban_user == $key->jawaban): ?>
                                                                                                <span
                                                                                                    class="badge badge-outline-success">Benar</span>
                                                                                            <?php else: ?>
                                                                                                <span
                                                                                                    class="badge badge-outline-danger">Salah</span>
                                                                                            <?php endif; ?>
                                                                                        <?php else: ?>
                                                                                            <span
                                                                                                class="badge badge-outline-secondary">Kosong</span>
                                                                                        <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                </h4>
                                                                            </div>
                                                                            <div class="col-6">
                                                                            </div>
                                                                        </div>
                                                                        <hr>
                                                                        <div class="_soal"><?php echo $key->soal; ?></div>
                                                                        <div class="form-group">
                                                                            <?php if($upaketsoalmst->jenis_penilaian == 1): ?>
                                                                                <div
                                                                                    class="form-check <?php echo e($key->jawaban == 'a' && $upaketsoalmst->bagi_jawaban == 1 ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'a' ? '_form-check-user' : ''); ?>">
                                                                                    <label class="form-check-label">
                                                                                        <input type="radio"
                                                                                            class="form-check-input _radio"
                                                                                            disabled
                                                                                            idpaketdtl="<?php echo e($key->id); ?>"
                                                                                            name="radio_<?php echo e($key->id); ?>"
                                                                                            value="a">
                                                                                        <i
                                                                                            class="input-helper"></i></label>
                                                                                    <div class="_pilihan">
                                                                                        <span><b>a.</b> </span>
                                                                                        <div class="_pilihan_isi">
                                                                                            <?php echo $key->a; ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="form-check <?php echo e($key->jawaban == 'b' && $upaketsoalmst->bagi_jawaban == 1 ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'b' ? '_form-check-user' : ''); ?>">
                                                                                    <label class="form-check-label">
                                                                                        <input type="radio"
                                                                                            class="form-check-input _radio"
                                                                                            disabled
                                                                                            idpaketdtl="<?php echo e($key->id); ?>"
                                                                                            name="radio_<?php echo e($key->id); ?>"
                                                                                            value="b">
                                                                                        <i
                                                                                            class="input-helper"></i></label>
                                                                                    <div class="_pilihan">
                                                                                        <span><b>b.</b> </span>
                                                                                        <div class="_pilihan_isi">
                                                                                            <?php echo $key->b; ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <?php if($key->c): ?>
                                                                                    <div
                                                                                        class="form-check <?php echo e($key->jawaban == 'c' && $upaketsoalmst->bagi_jawaban == 1 ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'c' ? '_form-check-user' : ''); ?>">
                                                                                        <label class="form-check-label">
                                                                                            <input type="radio"
                                                                                                class="form-check-input _radio"
                                                                                                disabled
                                                                                                idpaketdtl="<?php echo e($key->id); ?>"
                                                                                                name="radio_<?php echo e($key->id); ?>"
                                                                                                value="c">
                                                                                            <i
                                                                                                class="input-helper"></i></label>
                                                                                        <div class="_pilihan">
                                                                                            <span><b>c.</b> </span>
                                                                                            <div class="_pilihan_isi">
                                                                                                <?php echo $key->c; ?>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                                <?php if($key->d): ?>
                                                                                    <div
                                                                                        class="form-check <?php echo e($key->jawaban == 'd' && $upaketsoalmst->bagi_jawaban == 1 ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'd' ? '_form-check-user' : ''); ?>">
                                                                                        <label class="form-check-label">
                                                                                            <input type="radio"
                                                                                                class="form-check-input _radio"
                                                                                                disabled
                                                                                                idpaketdtl="<?php echo e($key->id); ?>"
                                                                                                name="radio_<?php echo e($key->id); ?>"
                                                                                                value="d">
                                                                                            <i
                                                                                                class="input-helper"></i></label>
                                                                                        <div class="_pilihan">
                                                                                            <span><b>d.</b> </span>
                                                                                            <div class="_pilihan_isi">
                                                                                                <?php echo $key->d; ?>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                                <?php if($key->e): ?>
                                                                                    <div
                                                                                        class="form-check <?php echo e($key->jawaban == 'e' && $upaketsoalmst->bagi_jawaban == 1 ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'e' ? '_form-check-user' : ''); ?>">
                                                                                        <label class="form-check-label">
                                                                                            <input type="radio"
                                                                                                class="form-check-input _radio"
                                                                                                disabled
                                                                                                idpaketdtl="<?php echo e($key->id); ?>"
                                                                                                name="radio_<?php echo e($key->id); ?>"
                                                                                                value="e">
                                                                                            <i
                                                                                                class="input-helper"></i></label>
                                                                                        <div class="_pilihan">
                                                                                            <span><b>e.</b> </span>
                                                                                            <div class="_pilihan_isi">
                                                                                                <?php echo $key->e; ?>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                            <?php elseif($upaketsoalmst->jenis_penilaian == 2): ?>
                                                                                <div
                                                                                    class="form-check <?php echo e($key->jawaban == 'a' ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'a' ? '_form-check-user' : ''); ?>">
                                                                                    <label class="form-check-label">
                                                                                        <input type="radio"
                                                                                            class="form-check-input _radio"
                                                                                            disabled
                                                                                            idpaketdtl="<?php echo e($key->id); ?>"
                                                                                            name="radio_<?php echo e($key->id); ?>"
                                                                                            value="a">
                                                                                        <i
                                                                                            class="input-helper"></i></label>
                                                                                    <div class="_pilihan">
                                                                                        <span><b>a.</b> </span>
                                                                                        <div class="_pilihan_isi">
                                                                                            <?php echo $key->a; ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="form-check <?php echo e($key->jawaban == 'b' ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'b' ? '_form-check-user' : ''); ?>">
                                                                                    <label class="form-check-label">
                                                                                        <input type="radio"
                                                                                            class="form-check-input _radio"
                                                                                            disabled
                                                                                            idpaketdtl="<?php echo e($key->id); ?>"
                                                                                            name="radio_<?php echo e($key->id); ?>"
                                                                                            value="b">
                                                                                        <i
                                                                                            class="input-helper"></i></label>
                                                                                    <div class="_pilihan">
                                                                                        <span><b>b.</b> </span>
                                                                                        <div class="_pilihan_isi">
                                                                                            <?php echo $key->b; ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="form-check <?php echo e($key->jawaban == 'c' ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'c' ? '_form-check-user' : ''); ?>">
                                                                                    <label class="form-check-label">
                                                                                        <input type="radio"
                                                                                            class="form-check-input _radio"
                                                                                            disabled
                                                                                            idpaketdtl="<?php echo e($key->id); ?>"
                                                                                            name="radio_<?php echo e($key->id); ?>"
                                                                                            value="c">
                                                                                        <i
                                                                                            class="input-helper"></i></label>
                                                                                    <div class="_pilihan">
                                                                                        <span><b>c.</b> </span>
                                                                                        <div class="_pilihan_isi">
                                                                                            <?php echo $key->c; ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="form-check <?php echo e($key->jawaban == 'd' ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'd' ? '_form-check-user' : ''); ?>">
                                                                                    <label class="form-check-label">
                                                                                        <input type="radio"
                                                                                            class="form-check-input _radio"
                                                                                            disabled
                                                                                            idpaketdtl="<?php echo e($key->id); ?>"
                                                                                            name="radio_<?php echo e($key->id); ?>"
                                                                                            value="d">
                                                                                        <i
                                                                                            class="input-helper"></i></label>
                                                                                    <div class="_pilihan">
                                                                                        <span><b>d.</b> </span>
                                                                                        <div class="_pilihan_isi">
                                                                                            <?php echo $key->d; ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="form-check <?php echo e($key->jawaban == 'e' ? '_form-check-success' : '_form-check-danger'); ?> <?php echo e($key->jawaban_user == 'e' ? '_form-check-user' : ''); ?>">
                                                                                    <label class="form-check-label">
                                                                                        <input type="radio"
                                                                                            class="form-check-input _radio"
                                                                                            disabled
                                                                                            idpaketdtl="<?php echo e($key->id); ?>"
                                                                                            name="radio_<?php echo e($key->id); ?>"
                                                                                            value="e">
                                                                                        <i
                                                                                            class="input-helper"></i></label>
                                                                                    <div class="_pilihan">
                                                                                        <span><b>e.</b> </span>
                                                                                        <div class="_pilihan_isi">
                                                                                            <?php echo $key->e; ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <hr>
                                                                        <h5><b>Jawaban</b> :
                                                                            <?php echo e($key->jawaban_user ? strtoupper($key->jawaban_user) : '-'); ?>

                                                                        </h5>
                                                                        <hr>
                                                                        <?php if($upaketsoalmst->bagi_jawaban == 1): ?>
                                                                            <h5><b>Kunci Jawaban</b> :
                                                                                <?php echo e(strtoupper($key->jawaban)); ?></h5>
                                                                            <h5><b>Pembahasan</b> :
                                                                                <br><?php echo $key->pembahasan; ?>

                                                                            </h5>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="row mb-3">
                                                                        <div class="col-6" style="text-align:right">
                                                                            <span>
                                                                                <?php if($loop->parent->first && $loop->first): ?>
                                                                                <?php else: ?>
                                                                                    <button idsoal="<?php echo e($key->id - 1); ?>"
                                                                                        type="button"
                                                                                        class="btn-next-back btn btn-sm btn-primary btn-rounded btn-fw">
                                                                                        <i
                                                                                            class="fa fa-long-arrow-left"></i>
                                                                                        Sebelumnya
                                                                                    </button>
                                                                                <?php endif; ?>
                                                                            </span>
                                                                        </div>
                                                                        <div class="col-6">
                                                                            <span>
                                                                                <?php if($loop->parent->last && $loop->last): ?>
                                                                                <?php else: ?>
                                                                                    <button idsoal="<?php echo e($key->id + 1); ?>"
                                                                                        type="button"
                                                                                        class="btn-next-back btn btn-sm btn-primary btn-rounded btn-fw">
                                                                                        Selanjutnya
                                                                                        <i
                                                                                            class="fa fa-long-arrow-right"></i>
                                                                                    </button>
                                                                                <?php endif; ?>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- <div class="tab-pane fade show active" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">2</div> -->
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php elseif($upaketsoalmst->jenis_pembahasan == 2): ?>
                                                    <?php echo $upaketsoalmst->pembahasan; ?>

                                                <?php endif; ?>
                                            </div>
                                            <div class="col-xl-3 col-md-3 col-sm-3 col-xs-3">
                                                <div class="card-border p-3 br-10 list-nomor">
                                                    <center class="mb-3 text-white">Nomor Soal</center>
                                                    <?php if($upaketsoalmst->bagi_jawaban == 1): ?>
                                                        <div class="row mb-2">
                                                            <div class="col-sm-4 col-md-4 col-lg-4"
                                                                style="padding-right:2.5px;"><i
                                                                    style="font-size:18px;color:#a3a4a5"
                                                                    class="fa fa-square"></i> <span
                                                                    style="font-size:12px; color: white;">Kosong</span>
                                                            </div>
                                                            <div class="col-sm-4 col-md-4 col-lg-4"
                                                                style="padding-right:2.5px;"><i
                                                                    style="font-size:18px;color:#63bb64"
                                                                    class="fa fa-square"></i> <span
                                                                    style="font-size:12px; color: white;">Benar</span>
                                                            </div>
                                                            <div class="col-sm-4 col-md-4 col-lg-4"
                                                                style="padding-right:2.5px;"><i
                                                                    style="font-size:18px;color:#FF4747"
                                                                    class="fa fa-square"></i> <span
                                                                    style="font-size:12px; color: white;">Salah</span>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                    <br>
                                                    <center class="mb-2 text-white">
                                                        <?php echo e($upaketsoalmst->jenis_waktu == 1 ? 'Kategori' : 'Sesi'); ?>

                                                    </center>
                                                    <?php $__currentLoopData = $upaketsoalmst->u_paket_soal_ktg_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upaketktg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <p class="text-white"><?php echo e($upaketktg->judul); ?></p>
                                                        <ul class="_soal nav nav-pills mb-0e" id="pills-tab"
                                                            role="tablist">
                                                            <?php $__currentLoopData = $upaketktg->u_paket_soal_dtl_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <!-- <li class="nav-item" role="presentation">
                                                                  <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">1</button>
                                                                </li> -->
                                                                <li class="nav-item" role="presentation">
                                                                    <button id="btn_no_soal_<?php echo e($key->id); ?>"
                                                                        class="
                              <?php if($key->jawaban_user && $upaketsoalmst->bagi_jawaban == 1): ?> <?php if($key->jawaban == $key->jawaban_user): ?>
                                      _benar
                                  <?php else: ?>
                                      _salah <?php endif; ?>
<?php else: ?>
_kosong
                              <?php endif; ?>
                              nav-link nav-link-soal <?php echo e($key->no_soal == 1 ? 'active' : ''); ?>"
                                                                        data-bs-toggle="pill"
                                                                        data-bs-target="#pills-<?php echo e($key->id); ?>"
                                                                        type="button" role="tab"
                                                                        aria-selected="true"><?php echo e($key->no_soal); ?></button>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <!-- jQuery -->
    <!-- SweetAlert2 -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            $(document).bind("contextmenu", function(e) {
                return false;
            });
            $('body').on("cut copy paste", function(e) {
                e.preventDefault();
            });
            $(document).on('click', '.list-nomor .nav-link', function(e) {
                $('.nav-link').removeClass('active');
                $(this).addClass('active');
            });
            $(document).on('click', '.btn-next-back', function(e) {
                idsoal = $(this).attr('idsoal');
                $('.tab-pane-soal').removeClass('show active');
                $('.nav-link-soal').removeClass('active');
                $('#pills-' + idsoal).addClass('show active');
                $('#btn_no_soal_' + idsoal).addClass('active');
            });
        });
    </script>
    <!-- Loading Overlay -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make($extend, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dharmara/apps.belajarsoal.id/laravel/resources/views/user/detailhasilpersesi.blade.php ENDPATH**/ ?>