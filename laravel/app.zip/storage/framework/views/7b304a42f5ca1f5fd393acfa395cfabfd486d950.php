<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card card-border" style="box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);">
                    <div class="card-body">
                        <h4 class="card-title text-black">FAQ</h4>
                        <div class="accordion" id="faqAccordion">

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading_<?php echo e($faq->id); ?>">
                                        <button class="accordion-button question" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#collapse_<?php echo e($faq->id); ?>" aria-expanded="true"
                                            aria-controls="collapse_<?php echo e($faq->id); ?>">
                                            <strong><?php echo e($faq->question); ?></strong>
                                        </button>
                                    </h2>
                                    <div id="collapse_<?php echo e($faq->id); ?>" class="accordion-collapse collapse"
                                        aria-labelledby="heading_<?php echo e($faq->id); ?>" data-bs-parent="#faqAccordion">
                                        <div class="accordion-body answer">
                                            <?php echo $faq->answer; ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .question {
            background-color: #007bff;
            /* Warna background untuk pertanyaan */
            color: white;
            /* Warna teks untuk pertanyaan */
        }

        .answer {
            background-color: #f8f9fa;
            /* Warna background untuk jawaban */
        }

        .accordion-button:not(.collapsed) {
            color: white;
            background-color: #0062cc;
            /* Warna background untuk pertanyaan ketika accordion dibuka */
            box-shadow: inset 0 -1px 0 rgba(0, 0, 0, .125);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Skydash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dharmara/apps.belajarsoal.id/laravel/resources/views/user/faq.blade.php ENDPATH**/ ?>