<!-- partial -->
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-12 col-xl-12 mb-4 mb-xl-0">
                        <h3 class="font-weight-bold">Hasil Ujian</h3>
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="justify-content-end d-flex">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <!-- Tab panes -->
                        <div class="tab-content tab-hasil-ujian">
                            <div id="umum" class="tab-pane active"><br>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Paket</th>
                                                <th>Tanggal Mengerjakan</th>
                                                <th>Passing Grade</th>
                                                <th>Skor Akhir</th>
                                                <th>Hasil Akhir</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(count($data) > 0): ?>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td width="1%"><?php echo e($loop->iteration); ?></td>
                                                        <td width="40%"><?php echo e($key->judul); ?></td>
                                                        <td width="10%">
                                                            <?php echo e(Carbon\Carbon::parse($key->mulai)->translatedFormat('l, d F Y , H:i:s')); ?>

                                                        </td>
                                                        <td width="5%"><?php echo e($key->kkm); ?></td>
                                                        <td width="10%" style="text-align:center">
                                                            <?php echo e($key->point <= 0 ? 0 : $key->point); ?>

                                                        </td>
                                                        <?php
                                                            if ($key->point < $key->kkm) {
                                                                $lulus = 0;
                                                            } else {
                                                                $lulus = 1;
                                                            }
                                                        ?>
                                                        <td width="10%">
                                                            <label
                                                                class="<?php echo e(statuslulus($lulus, 2)); ?>"><?php echo e(statuslulus($lulus, 1)); ?></label>
                                                            <a
                                                                href="<?php echo e(url('detailhasil')); ?>/<?php echo e(Crypt::encrypt($key->id)); ?>">
                                                                <label class="_hover badge badge-info">Lihat Jawaban</label>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="6" style="text-align:center" class="font-weight-bold">
                                                        Belum Ada Data</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div id="kecermatan" class="tab-pane fade"><br>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Paket</th>
                                                <th>Tanggal Mengerjakan</th>
                                                <th>Passing Grade</th>
                                                <th>Skor Akhir</th>
                                                <th>Lulus</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(count($datakecermatan) > 0): ?>
                                                <?php $__currentLoopData = $datakecermatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td width="1%"><?php echo e($loop->iteration); ?></td>
                                                        <td width="40%"><?php echo e($key->judul); ?></td>
                                                        <td width="10%">
                                                            <?php echo e(Carbon\Carbon::parse($key->mulai)->translatedFormat('l, d F Y , H:i:s')); ?>

                                                        </td>
                                                        <td width="5%"><?php echo e($key->kkm); ?></td>
                                                        <td width="10%" style="text-align:center">
                                                            <?php echo e($key->nilai ? $key->nilai : 0); ?></td>
                                                        <?php
                                                            if ($key->nilai < $key->kkm) {
                                                                $lulus = 0;
                                                            } else {
                                                                $lulus = 1;
                                                            }
                                                        ?>
                                                        <td width="10%">
                                                            <label
                                                                class="<?php echo e(statuslulus($lulus, 2)); ?>"><?php echo e(statuslulus($lulus, 1)); ?></label>
                                                            <a
                                                                href="<?php echo e(url('detailhasilkecermatan')); ?>/<?php echo e(Crypt::encrypt($key->id)); ?>">
                                                                <label class="_hover badge badge-info">Detail</label>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="6" style="text-align:center" class="font-weight-bold">
                                                        Belum Ada Data</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <!-- jQuery -->
    <script>
        $(document).ready(function() {
            // alert('x');
        });
    </script>
    <!-- Loading Overlay -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Skydash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dharmara/apps.belajarsoal.id/laravel/resources/views/user/hasilujian.blade.php ENDPATH**/ ?>